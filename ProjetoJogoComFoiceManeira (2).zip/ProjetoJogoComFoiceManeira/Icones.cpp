#include "Icones.h"

Icones::Icones(sf::Vector2f posicao, int quantidade) :
	posicao (posicao),
	quantidade(quantidade)
{
	
}

Icones::~Icones()
{
}



void Icones::draw()
{
}
