
#include "Jogo.h"

int main() {
	
	Jogo jogo;

	return 0;
}