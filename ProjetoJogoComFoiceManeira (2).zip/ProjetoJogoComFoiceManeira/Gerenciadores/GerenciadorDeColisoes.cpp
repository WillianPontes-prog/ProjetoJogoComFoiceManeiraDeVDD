#include "GerenciadorDeColisoes.h"
#include "Jogo.h"
#include "MudarFase.h"

using namespace Fases;
using namespace Listas;
using namespace Entidades::Obstaculos;
using namespace Entidades::Personagens;
namespace Gerenciadores {

    GerenciadorDeColisoes::GerenciadorDeColisoes(Fase* fase) :
        listaJogador(new Lista<Entidades::Personagens::Jogador*>()),
        listaPlataforma(new Lista<Entidades::Obstaculos::Plataforma*>()),
        listaInimigos(new std::vector<Entidades::Personagens::Inimigo*>()),
        listaObstaculos(new std::list<Entidades::Obstaculos::Obstaculo*>()),
        mudarFase(nullptr)
    {
        this->fase = fase;
    }

    GerenciadorDeColisoes::~GerenciadorDeColisoes()
    {
    }

    void GerenciadorDeColisoes::tratarColisoes()
    {
        //--itera sobre cada jogador e todos obstaculos--\\
        ===================================================

        tratarColisaoJogJog();

        tratarColisaoJogObst();

        tratarColisaoJogInim();

        tratarColisaoJogProjetil();

        tratarColisaInimProj();

    }

    void GerenciadorDeColisoes::danoJogador(Jogador* jogador, int dirX)
    {

        jogador->setState(Jogador::Machucado);

        jogador->setVspd(-8);
        jogador->setHspd(dirX * 6);
    }

    Listas::Lista<Jogador*>* GerenciadorDeColisoes::getListaJogadores()
    {
        return listaJogador;
    }

    Listas::Lista<Entidades::Obstaculos::Plataforma*>* GerenciadorDeColisoes::getListaPlataforma()
    {
        return listaPlataforma;
    }

    std::vector<Inimigo*>* GerenciadorDeColisoes::getListaInimigos()
    {
        return listaInimigos;
    }

    std::list<Entidades::Obstaculos::Obstaculo*>* GerenciadorDeColisoes::getListaObstaculos()
    {
        return listaObstaculos;
    }

    void GerenciadorDeColisoes::tratarColisaoJogObst()
    {
        for (Lista<Jogador*>::iterator itJog = listaJogador->begin(); itJog != listaJogador->end(); ++itJog) {

            sf::RectangleShape bodyTemp;


            (*itJog)->setSobAtrito(false);

            //--itera sobre todas plataformas--\\
            =====================================
            for (Lista<Plataforma*>::iterator it = listaPlataforma->begin(); it != listaPlataforma->end(); ++it) {

                //--percep��o do jogador no ch�o--\\
                ===================================

                bodyTemp = (*itJog)->getBody();
                bodyTemp.move(sf::Vector2f(0, 1));

                if (ChecarColisao(bodyTemp, (*it)->getBody())) {
                    (*itJog)->setNoChao(true);

                    if (!(*itJog)->getSobAtrito()) {
                        (*it)->Obstacular((*itJog));

                    }
                }


                //--gerenciador de colis�o--\\
                =============================

                bodyTemp = (*itJog)->getBody();
                bodyTemp.move(sf::Vector2f((*itJog)->getHspd(), 0));

                if (ChecarColisao(bodyTemp, (*it)->getBody())) {
                    bodyTemp = (*itJog)->getBody();
                    bodyTemp.move(sf::Vector2f(NumeroMinimo((*itJog)->getHspd()), 0));

                    while (!ChecarColisao(bodyTemp, (*it)->getBody())) {
                        (*itJog)->getBodyPtr()->move(sf::Vector2f(NumeroMinimo((*itJog)->getHspd()), 0));

                        bodyTemp = (*itJog)->getBody();
                        bodyTemp.move(sf::Vector2f(NumeroMinimo((*itJog)->getHspd()), 0));
                    }

                    (*itJog)->setHspd(0);
                }

                bodyTemp = (*itJog)->getBody();
                bodyTemp.move(sf::Vector2f((*itJog)->getHspd(), (*itJog)->getVspd()));

                if (ChecarColisao(bodyTemp, (*it)->getBody())) {
                    bodyTemp = (*itJog)->getBody();
                    bodyTemp.move(sf::Vector2f((*itJog)->getHspd(), NumeroMinimo((*itJog)->getVspd())));

                    while (!ChecarColisao(bodyTemp, (*it)->getBody())) {
                        (*itJog)->getBodyPtr()->move(sf::Vector2f(0, NumeroMinimo((*itJog)->getVspd())));

                        bodyTemp = (*itJog)->getBody();
                        bodyTemp.move(sf::Vector2f((*itJog)->getHspd(), NumeroMinimo((*itJog)->getVspd())));
                    }

                    (*itJog)->setVspd(0);
                }

            }


            //--itera sobre todos os obstaculos--\\
            ======================================
            for (std::list<Obstaculo*>::iterator it = listaObstaculos->begin(); it != listaObstaculos->end(); ++it) {

                if (ChecarColisao((*itJog)->getBody(), (*it)->getBody())) {
                    ObstaculoDano* obstaculo1 = dynamic_cast<ObstaculoDano*>(*it);
                    ObstaculoTeleporte* obstaculo2 = dynamic_cast<ObstaculoTeleporte*>(*it);

                    if (obstaculo1) {

                        obstaculo1->Obstacular(*itJog);
                        int dir = NumeroMinimo((*itJog)->getBody().getPosition().x - (*it)->getBody().getPosition().x);
                        danoJogador(*itJog, dir);

                    }

                    if (obstaculo2) {
                        obstaculo2->Obstacular(*itJog);
                    }

                }
            }


            (*itJog)->getBodyPtr()->move(sf::Vector2f((*itJog)->getHspd(), (*itJog)->getVspd()));

            if ((*itJog)->getVoador()) {
                (*itJog)->setNoChao(true);
            }
        }
    }

    void GerenciadorDeColisoes::tratarColisaoJogInim()
    {
        //--itera sobre cada inimigo--\\
       ================================
        for (std::vector<Inimigo*>::iterator itIni = listaInimigos->begin(); itIni != listaInimigos->end(); ++itIni) {

            sf::RectangleShape bodyTemp;


            //==intera��o inimigo e jogador===========================================================================================================================================

            for (Lista<Jogador*>::iterator itJog = listaJogador->begin(); itJog != listaJogador->end(); ++itJog) {



                if ((*itJog)->getState() == Jogador::Machucado) {
                    continue;
                }

                bodyTemp = (*itIni)->getBody();
                bodyTemp.move(sf::Vector2f((*itIni)->getHspd(), (*itIni)->getVspd()));

                if (ChecarColisao(bodyTemp, (*itJog)->getBody())) {

                    float dirX = NumeroMinimo((*itJog)->getBody().getPosition().x - (*itIni)->getBody().getPosition().x);
                    (*itIni)->danificar((*itJog));
                    danoJogador(*itJog, dirX);

                }
            }


            //==intera��o inimigo e plataforma========================================================================================================================================

                //--seta por padr�o que o inimigo n�o est� no ch�o e o proximo passo no chao--\\
                ================================================================================
            (*itIni)->setNoChao(false);
            bool invertFlag = true;
            bool invertFlagY = true;
            ZumbiFriorento* inimigo1 = dynamic_cast<ZumbiFriorento*>(*itIni);
            Zumbinana* inimigo2 = dynamic_cast<Zumbinana*>(*itIni);

            //--itera sobre todas plataformas--\\
            =====================================
            for (Lista<Plataforma*>::iterator it = listaPlataforma->begin(); it != listaPlataforma->end(); ++it) {


                //--inverte a dire��o do inimigo--\\
                ====================================
                if (inimigo1 || inimigo2) {
                    bodyTemp = (*itIni)->getBody();
                    bodyTemp.move(sf::Vector2f(NumeroMinimo((*itIni)->getHspd()) * bodyTemp.getSize().x, 0));

                    if (!ChecarColisao(bodyTemp, (*it)->getBody())) {
                        bodyTemp.move(sf::Vector2f(0, 1));

                        if (ChecarColisao(bodyTemp, (*it)->getBody()) && invertFlagY) {
                            invertFlag = false;
                            invertFlagY = false;
                        }
                    }
                    else {
                        invertFlag = true;
                        invertFlagY = false;
                    }
                }

                //--gerenciador de colis�o--\\
                =============================
                bodyTemp = (*itIni)->getBody();
                bodyTemp.move(sf::Vector2f((*itIni)->getHspd(), 0));

                if (ChecarColisao(bodyTemp, (*it)->getBody())) {
                    bodyTemp = (*itIni)->getBody();
                    bodyTemp.move(sf::Vector2f(NumeroMinimo((*itIni)->getHspd()), 0));

                    while (!ChecarColisao(bodyTemp, (*it)->getBody())) {
                        (*itIni)->getBodyPtr()->move(sf::Vector2f(NumeroMinimo((*itIni)->getHspd()), 0));

                        bodyTemp = (*itIni)->getBody();
                        bodyTemp.move(sf::Vector2f(NumeroMinimo((*itIni)->getHspd()), 0));
                    }

                    (*itIni)->setHspd(0);
                }

                bodyTemp = (*itIni)->getBody();
                bodyTemp.move(sf::Vector2f((*itIni)->getHspd(), (*itIni)->getVspd()));

                if (ChecarColisao(bodyTemp, (*it)->getBody())) {
                    bodyTemp = (*itIni)->getBody();
                    bodyTemp.move(sf::Vector2f((*itIni)->getHspd(), NumeroMinimo((*itIni)->getVspd())));

                    while (!ChecarColisao(bodyTemp, (*it)->getBody())) {
                        (*itIni)->getBodyPtr()->move(sf::Vector2f(0, NumeroMinimo((*itIni)->getVspd())));

                        bodyTemp = (*itIni)->getBody();
                        bodyTemp.move(sf::Vector2f((*itIni)->getHspd(), NumeroMinimo((*itIni)->getVspd())));
                    }

                    (*itIni)->setVspd(0);
                }

            }

            if (invertFlag) {
                if (inimigo1)
                    inimigo1->invertDirectionX();
                else if (inimigo2)
                    inimigo2->invertDirectionX();
            }

            (*itIni)->getBodyPtr()->move(sf::Vector2f((*itIni)->getHspd(), (*itIni)->getVspd()));

            //=========================================================================================================================================================================

        }
    }

    void GerenciadorDeColisoes::tratarColisaoJogJog()
    {
        for (Lista<Jogador*>::iterator itJog = listaJogador->begin(); itJog != listaJogador->end(); ++itJog) {
            if (mudarFase) {
                if (ChecarColisao((*itJog)->getBody(), mudarFase->getBody())) {
                    mudarFase->executa();
                }
            }

            sf::RectangleShape bodyTemp;
            //--seta por padr�o que o jogador n�o est� no ch�o--\\
                ====================================================
            (*itJog)->setNoChao(false);

            //--colis�o Jogador com jogador--\\
                ===================================

            for (Lista<Jogador*>::iterator itJogColider = listaJogador->begin(); itJogColider != listaJogador->end(); ++itJogColider) {

                if ((*itJog) != (*itJogColider)) {

                    //--percep��o do jogador com jogador--\\
                        ========================================

                    bodyTemp = (*itJog)->getBody();
                    bodyTemp.move(sf::Vector2f(0, 1));

                    if (ChecarColisao(bodyTemp, (*itJogColider)->getBody())) {
                        (*itJog)->setNoChao(true);
                    }

                    //--gerenciador de colis�o--\\
                        =============================


                    bodyTemp = (*itJog)->getBody();
                    bodyTemp.move(sf::Vector2f((*itJog)->getHspd(), 0));

                    if (ChecarColisao(bodyTemp, (*itJogColider)->getBody())) {
                        bodyTemp = (*itJog)->getBody();
                        bodyTemp.move(sf::Vector2f(NumeroMinimo((*itJog)->getHspd()), 0));

                        while (!ChecarColisao(bodyTemp, (*itJogColider)->getBody())) {
                            (*itJog)->getBodyPtr()->move(sf::Vector2f(NumeroMinimo((*itJog)->getHspd()), 0));

                            bodyTemp = (*itJog)->getBody();
                            bodyTemp.move(sf::Vector2f(NumeroMinimo((*itJog)->getHspd()), 0));
                        }

                        (*itJog)->setHspd(0);
                    }

                    bodyTemp = (*itJog)->getBody();
                    bodyTemp.move(sf::Vector2f((*itJog)->getHspd(), (*itJog)->getVspd()));

                    if (ChecarColisao(bodyTemp, (*itJogColider)->getBody())) {
                        bodyTemp = (*itJog)->getBody();
                        bodyTemp.move(sf::Vector2f((*itJog)->getHspd(), NumeroMinimo((*itJog)->getVspd())));

                        while (!ChecarColisao(bodyTemp, (*itJogColider)->getBody())) {
                            (*itJog)->getBodyPtr()->move(sf::Vector2f(0, NumeroMinimo((*itJog)->getVspd())));

                            bodyTemp = (*itJog)->getBody();
                            bodyTemp.move(sf::Vector2f((*itJog)->getHspd(), NumeroMinimo((*itJog)->getVspd())));
                        }

                        (*itJog)->setVspd(0);
                    }
                }
            }
        }
    }

    void GerenciadorDeColisoes::tratarColisaoJogProjetil()
    {
        for (std::vector<Inimigo*>::iterator itIni = listaInimigos->begin(); itIni != listaInimigos->end(); ++itIni) {

            sf::RectangleShape bodyTemp;


            //==intera��o inimigo e jogador===========================================================================================================================================

            for (Lista<Jogador*>::iterator itJog = listaJogador->begin(); itJog != listaJogador->end(); ++itJog) {

                for (Lista<Entidades::Projetil*>::iterator itProjI = (*itIni)->getListaProjetil()->begin(); itProjI != (*itIni)->getListaProjetil()->end(); ++itProjI) {

                    if (ChecarColisao((*itJog)->getBody(), (*itProjI)->getBody())) {

                        (*itProjI)->destruir();

                        if ((*itJog)->getState() == Jogador::Machucado) {
                            continue;
                        }

                        int direcao = NumeroMinimo((*itJog)->getBody().getPosition().x - (*itIni)->getBody().getPosition().x);

                        (*itJog)->operator--();
                        danoJogador((*itJog), direcao);

                    }
                }
            }
        }
    }

    void GerenciadorDeColisoes::tratarColisaInimProj()
    {
        //--itera sobre cada inimigo--\\
       ================================
        for (std::vector<Inimigo*>::iterator itIni = listaInimigos->begin(); itIni != listaInimigos->end(); ++itIni) {

            sf::RectangleShape bodyTemp;


            //==intera��o inimigo e jogador===========================================================================================================================================

            for (Lista<Jogador*>::iterator itJog = listaJogador->begin(); itJog != listaJogador->end(); ++itJog) {



                //==itera��o sobre todos os tiros de cada jogador=====================================================================================================================
                for (Lista<Entidades::Projetil*>::iterator itProjJ = (*itJog)->getListaProjetil()->begin(); itProjJ != (*itJog)->getListaProjetil()->end(); ++itProjJ) {



                    if (ChecarColisao((*itIni)->getBody(), (*itProjJ)->getBody())) {
                        (*itProjJ)->destruir();

                        (*itIni)->operator--((*itProjJ)->getDano());
                    }

                    //==itera��o sobre todas as plataformas===========================================================================================================================
                    for (Lista<Plataforma*>::iterator itPlat = listaPlataforma->begin(); itPlat != listaPlataforma->end(); ++itPlat) {
                        if (ChecarColisao((*itProjJ)->getBody(), (*itPlat)->getBody())) {
                            (*itProjJ)->destruir();
                        }
                    }
                }
            }
        }
    }
}


