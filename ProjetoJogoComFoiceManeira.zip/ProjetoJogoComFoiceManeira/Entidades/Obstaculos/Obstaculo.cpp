#include "Obstaculo.h"

namespace Entidades {
	namespace Obstaculos {
		Obstaculo::Obstaculo(int posX, int posY) : Entidade(posX, posY, 32, 32)
		{
		}

		Obstaculo::~Obstaculo()
		{
		}
	}
}
